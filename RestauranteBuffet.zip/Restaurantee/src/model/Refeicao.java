
package model;


public class Refeicao {
    
    private int id;
    private double valor_refeicao;

    public Refeicao() {
    }

    public Refeicao(double valor_refeicao) {
        this.valor_refeicao = valor_refeicao;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getValor_refeicao() {
        return valor_refeicao;
    }

    public void setValor_refeicao(double valor_refeicao) {
        this.valor_refeicao = valor_refeicao;
    }
    
}
