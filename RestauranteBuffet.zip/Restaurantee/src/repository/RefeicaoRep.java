package repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Refeicao;
import util.ConexaoBD;

public class RefeicaoRep {

    private static final String INSERT = "insert into refeicao (valor_refeicao) values (?)";

    private static final String SELECT = "select id_refeicao, valor from refeicao";

    private static final String DELETE = "delete from refeicao where id_refeicao = ?";

    private static final String UPDATE = "update refeicao set valor_refeicao = ?, where id_refeicao = ?";

    private Connection connection = ConexaoBD.conectarBanco();
    private PreparedStatement pstm;

    public void salvar(Refeicao refeicao) {
        try {

            if (refeicao.getId() > 0) {
                pstm = connection.prepareStatement(UPDATE);
                pstm.setInt(1, refeicao.getId());                
                pstm.setDouble(2, refeicao.getValor_refeicao());
                
            } else {
                pstm = connection.prepareStatement(INSERT);
                pstm.setDouble(1, refeicao.getValor_refeicao());
            }

            pstm.execute();
            pstm.close();
        } catch (SQLException ex) {
            System.out.println("Ocorreu um erro ao tentar salvar: " + ex.getMessage());
        }
    }

    public List<Refeicao> listar() {
        List<Refeicao> buffet = new ArrayList<>();
        ResultSet res;

        try {
            pstm = connection.prepareStatement(SELECT);
            res = pstm.executeQuery();

            while (res.next()) {
                Refeicao r = new Refeicao();
                r.setId(res.getInt("id_consumo"));
                r.setValor_refeicao(res.getDouble("valor_refeicao"));                
                buffet.add(r);
            }

        } catch (SQLException ex) {
            System.out.println("Ocorreu um erro ao tentar buscar os estudantes do banco: " + ex.getMessage());
        }
        return buffet;
    }
}