
package repository;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Reebastecer;
import util.ConexaoBD;

public class ReebastecerRep {
  
    
    private static final String INSERT = "insert into reebastecer (quantidade_estoque, id_produto) values (?, ?)";

    private static final String SELECT = "select quantidade_estoque, id_produto from reebastecer";

    private static final String DELETE = "delete from reebastecer where id_produto = ?";

    private static final String UPDATE = "update reebastecer set quantidade_estoque = ? where id_produto = ?";

    private Connection connection = ConexaoBD.conectarBanco();
    private PreparedStatement pstm;

    public void salvar(Reebastecer reebastecer) {
        try {

            if (reebastecer.getQuantidadeEstoque()> 0) {
                pstm = connection.prepareStatement(UPDATE);
                pstm.setInt(1, reebastecer.getQuantidadeEstoque());
                pstm.setInt(2, reebastecer.getId());
                
                System.out.println("update");
                
            } else {
                pstm = connection.prepareStatement(INSERT);
                pstm.setInt(2, reebastecer.getId());
                pstm.setInt(1, reebastecer.getQuantidadeEstoque());   
                System.out.println("insert");
            }

            pstm.execute();
            pstm.close();
        } catch (SQLException ex) {
            System.out.println("Ocorreu um erro ao tentar salvar: " + ex.getMessage());
        }
    }

    public List<Reebastecer> listar() {
        List<Reebastecer> buffet = new ArrayList<>();
        ResultSet res;

        try {
            pstm = connection.prepareStatement(SELECT);
            res = pstm.executeQuery();

            while (res.next()) {
                Reebastecer r = new Reebastecer();
                r.setId(res.getInt("id_produto"));
                r.setQuantidadeEstoque(res.getInt("quantidade_estoque"));
                buffet.add(r);
            }

        } catch (SQLException ex) {
            System.out.println("Ocorreu um erro ao tentar buscar os estudantes do banco: " + ex.getMessage());
        }
        return buffet;
    }
}


